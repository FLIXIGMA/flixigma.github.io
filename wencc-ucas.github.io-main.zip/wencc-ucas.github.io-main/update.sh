git add .
git commit -m 'initial'
git push
